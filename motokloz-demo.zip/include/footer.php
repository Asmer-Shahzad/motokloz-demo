<footer class="footer">
    <div class="container">
        <div class="footer-top">
            <div class="row">
                <div class="col-lg-8">
                    <h3>Subscribe to see secret deals prices drop the moment you sign up!</h3>
                </div>
                <div class="subscribe-box col-lg-4">
                    <input type="email" placeholder="Enter your Email">
                    <button type="submit">Subscribe</button>
                </div>
            </div>
        </div>
        <div class="footer-mid">
            <div class="row">
                <div class="col-lg-5">
                    <img src="<?php echo $prefix; ?>/assets/images/darklogo.png" class="img-fluid" alt="Motokloz Logo">
                    <ul>
                        <li><i class="fa-sharp fa-solid fa-location-dot"></i><a href="#">2356 Oakwood Drive, Suite
                                18, San Francisco, California 94111, US</a></li>
                        <li><i class="fa-sharp fa-solid fa-clock"></i><a href="#">Hours: 8:00 - 17:00, Mon - Sat</a>
                        </li>
                        <li><i class="fa-sharp fa-solid fa-envelope"></i><a
                                href="mailto:support@carento.com">support@carento.com</a></li>
                    </ul>
                    <div class="calltoaction">
                        <h5><i class="fa-sharp fa-solid fa-phone"></i> Need help? Call us</h5>
                        <h6><a href="tel:+8773475569">877-347-5569</a></h6>
                    </div>
                </div>
                <div class="col-lg-2">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Our Awards</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Merchandise</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Privacy Notice</a></li>
                        <li><a href="#">Press Releases</a></li>
                    </ul>
                </div>

                <!-- <div class="col-lg-2">
                        <h4>Our Partners</h4>
                        <ul>
                            <li><a href="#">Affiliates</a></li>
                            <li><a href="#">Travel Agents</a></li>
                            <li><a href="#">AARP Members</a></li>
                            <li><a href="#">Points Programs</a></li>
                            <li><a href="#">Military & Veterans</a></li>
                            <li><a href="#">Work with us</a></li>
                            <li><a href="#">Advertise with us</a></li>
                        </ul>
                    </div> -->
                <div class="col-lg-3">
                    <h4>Our Services</h4>
                    <ul>
                        <li><a href="#">Virtual Walk Arounds</a></li>
                        <li><a href="#">Prebid Trade</a></li>
                        <li><a href="#">Buyer Checklist</a></li>
                        <li><a href="#">Seller Checklists</a></li>
                        <li><a href="#">Secure The Best Approval</a></li>
                        <li><a href="#">Get Verified</a></li>
                    </ul>
                </div>
                <div class="col-lg-2">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Forum support</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Live chat</a></li>
                        <li><a href="#">Ad Guideline</a></li>
                        <li><a href="#">Ad Support</a></li>
                        <li><a href="#">Faq’s</a></li>
                        <li><a href="#">Dealer Support</a></li>
                    </ul>
                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="row">
                <div class="col-lg-6">
                    <p>© 2026 <span>Motokloz</span>. All rights reserved.</p>
                </div>
                <div class="col-lg-6">
                    <ul>
                        <li>Follow us</li>
                        <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-x-twitter"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>