<div class="row">
    <div class="col-lg-2 user-breadcrumbs">
        <ul>
            <li>Home</li>
            <li><?php echo $pageTitle; ?></li>
        </ul>
    </div>
</div>